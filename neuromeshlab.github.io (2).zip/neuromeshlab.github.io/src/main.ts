import './styles.css';
import { mountApp } from './mountApp';

mountApp(document.getElementById('app') as HTMLElement);


